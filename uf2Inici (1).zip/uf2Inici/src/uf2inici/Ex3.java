/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uf2inici;
import java.util.Scanner;
/**
 *
 * @author Susana
 */
public class Ex3 {

    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        double op1, op2, resultat = 0;
        String opcio = "-1";
        char oper = '+';
        boolean correcta;
        System.out.println("CALCULADORA ARITMÈTICA\n");
        
        //Sense validar les dades d'entrada
        System.out.println("Introduir operand 1:");
        op1 = lector.nextDouble();

        System.out.println("Introduir operand 2:");
        op2 = lector.nextDouble();

        while (true) {
            //Mostrem el menú amb les operacions
            System.out.println("1. SUMA\n2. RESTA\n3. MULTIPLICACIÓ"
                    + "\n4. DIVISIÓ\n5. SORTIR");
            //Demanem l'operació
            System.out.println("Selecionar operació");

            opcio = lector.next();
            correcta = true;

            switch (opcio) {
                case "1":
                    resultat = op1 + op2;
                    oper = '+';
                    break;
                case "2":
                    resultat = op1 - op2;
                    oper = '-';
                    break;
                case "3":
                    resultat = op1 * op2;
                    oper = 'x';
                    break;
                case "4":
                    if (op2 == 0) {
                        System.out.println("No es pot dividir entre 0");
                        correcta = false;
                    } else {
                        resultat = op1 / op2;
                        oper = '/';
                    }
                    break;
                case "5": //Finalitzar
                    System.exit(0);
                default:
                    System.out.println("Opció incorrecta");
                    correcta = false;
            }
            if (correcta) {
               
                System.out.println("Resultat: " + op1 + " " + oper + " " + op2
                        + " = " +  String.format("%.2f", resultat));
            }
        } 
    }
}
