/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uf2inici;

import java.util.Scanner;

/**
 *
 * @author super
 */
public class Ex1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double base, h, area;
        Scanner dades = new Scanner(System.in);
        
        System.out.println("Introduïr Base (cm):");      
        base = dades.nextDouble();
        
        System.out.println("Introduïr h (cm) :");
        h = dades.nextDouble();
        
        area = base*h/2;
        
        System.out.printf("Area triangle amb base %.2f i altura %.2f és %.2f cm\u00B2",base, h, area);
    }
    
}
