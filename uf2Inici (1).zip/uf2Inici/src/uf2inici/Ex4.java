/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uf2inici;
import java.util.Scanner;
/**
 *
 * @author Susana
 */
public class Ex4 {

    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        int numero;
        int n=1;
        
        //Demanar i validar l'entrada d'un enter positiu
        System.out.println("Introduir un nombre enter positiu: ");
        do {
            if (lector.hasNextInt()) {
                numero = lector.nextInt();
                if (numero > 0) {
                    break; //sortim del bucle
                }
            }
            lector.nextLine();
            System.out.println("Dada incorrecta");
        } while (true);

       //Obtenir els divisors
       while(n<numero){
           
           //comprovar si numero és dividible
           if(numero%n==0){
               System.out.print(n+", ");
           }
           
           //incrementar n en una unitat
           n++;
       }
       //s'afegeix l'últim divisor sense coma
        System.out.println(numero);
       
    }

}
